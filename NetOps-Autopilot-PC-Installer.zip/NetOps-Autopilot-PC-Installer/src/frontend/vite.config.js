import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    cors: true,
    headers: {
      'X-Frame-Options': 'ALLOWALL'
    },
    hmr: {
      clientPort: 443
    },
    proxy: {
      '/api': 'http://localhost:8000'
    }
  },
  preview: { host: '0.0.0.0', port: 4173, allowedHosts: true }
})
